public class Magician extends Role {
    public void fight() {
        System.out.println("揮劍攻擊");
    }

    public void cure() {
        System.out.println("魔法治療");
    }
}
