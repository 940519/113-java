public interface Greeting {
    void sayHello();
}
