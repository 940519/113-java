public interface Flyer {
    public abstract void fly();
}
