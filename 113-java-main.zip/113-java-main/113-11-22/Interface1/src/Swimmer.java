public interface Swimmer {
    public abstract void swim();
}
