public class helloworld {
    public static void main(String[] arge){
        System.out.println("Hello World");
    }
}
